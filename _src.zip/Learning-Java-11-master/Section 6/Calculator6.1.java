import java.util.ArrayList;

interface Calculator {
    double add(ArrayList<Double> numbers);
    double sub(ArrayList<Double> numbers);
    double mult(ArrayList<Double> numbers);
    double div(double x, double y);
}