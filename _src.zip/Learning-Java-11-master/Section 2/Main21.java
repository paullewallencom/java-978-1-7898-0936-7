public class Main {
    /*
    reserved words: class, public, static, void, int, String
    variables: hello_world, hello, cool, 9sd2, 47ds
    blocks of code: { }
    expressions: (a + 2 * 43)
    array items: [4]
    statements: ;
    String: " "
    characters: 'ads'
     */
    public static void main(String[] args) {
        // if 1 == 1
        if (1 == 1) {
            String a = "My first program"; // a string
            System.out.println(a);
        }
    }
}