public class Main {
    public static void main(String[] args) {
        // x = 5
        // a + b
        // !sad
        // a < 21
        // +, -, *, /
        int i = 3;
        int j = 2;
        System.out.println(i / j);
        String a = "Hello";
        String b = "Hello";
          System.out.println(a + b);
        i += 2; // i = i + 2
        System.out.println(a.equals(b));
        // AND == &&, OR == ||
        System.out.println(true || false);
    }
}