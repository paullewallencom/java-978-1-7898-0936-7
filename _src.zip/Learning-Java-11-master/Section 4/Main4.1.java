public class Main {
    // name = main
    // arguments = args
    // return type = void
    // access modifiers = public static
    public static void main(String[] args) {
        // body
        int variable = add(5, 10);
        System.out.println(variable);
    }

    public static int add(int x, int y) {
        return x + y;
    }
}