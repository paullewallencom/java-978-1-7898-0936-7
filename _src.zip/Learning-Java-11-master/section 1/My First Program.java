// Step 1: class name

// Step 2: methods

// Step 3: code
public class Main {
    public static void main(String[] args) {
        if (1 == 1) {
            String a = "My first program";
            System.out.println(a);
        }
    }
}